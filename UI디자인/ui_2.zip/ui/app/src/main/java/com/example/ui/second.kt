package com.example.ui

import android.app.Activity
import android.content.Intent
import android.media.Image
import android.os.Bundle
import android.widget.ImageButton
import android.widget.Toast

class second : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.select_food)

        var ko_food : ImageButton = findViewById<ImageButton>(R.id.ko_food)
        var jp_food : ImageButton = findViewById<ImageButton>(R.id.jp_food)
        var ch_food : ImageButton = findViewById<ImageButton>(R.id.ch_food)
        var fast_food : ImageButton = findViewById<ImageButton>(R.id.fast_food)
        var west_food : ImageButton = findViewById<ImageButton>(R.id.west_food)
        var world_food : ImageButton = findViewById<ImageButton>(R.id.world_food)
        var dessert : ImageButton = findViewById<ImageButton>(R.id.dessert)
        var snack : ImageButton = findViewById<ImageButton>(R.id.snack)

        var btnReturn = findViewById<ImageButton>(R.id.back)
        btnReturn.setOnClickListener{
            finish()
        }

        ko_food.setOnClickListener{
            Toast.makeText(getApplicationContext(), "한식 입니다!!", Toast.LENGTH_SHORT).show();
        }

        jp_food.setOnClickListener{
            Toast.makeText(getApplicationContext(), "일식 입니다!!", Toast.LENGTH_SHORT).show();
        }

        ch_food.setOnClickListener{
            Toast.makeText(getApplicationContext(), "중식 입니다!!", Toast.LENGTH_SHORT).show();
        }

        fast_food.setOnClickListener{
            Toast.makeText(getApplicationContext(), "패스트푸드 입니다!!!", Toast.LENGTH_SHORT).show();
        }

        west_food.setOnClickListener{
            Toast.makeText(getApplicationContext(), "양식 입니다!!", Toast.LENGTH_SHORT).show();
        }

        world_food.setOnClickListener{
            Toast.makeText(getApplicationContext(), "세계음식 입니다!!", Toast.LENGTH_SHORT).show();
        }

        snack.setOnClickListener{
            Toast.makeText(getApplicationContext(), "분식 입니다!!", Toast.LENGTH_SHORT).show();
        }

        dessert.setOnClickListener{
            var goto = Intent(application, end::class.java)
                startActivity(goto)
                finish()
        }
    }
}